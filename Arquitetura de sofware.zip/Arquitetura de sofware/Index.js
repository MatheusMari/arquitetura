const Aluno = require('./Aluno ');
const TurmaPresencial = require('./TurmaPresencial');

// Criando instância de aluno
const aluno1 = new Aluno('João Silva', 'joao123', 'RA12345');

// Criando instância de turma presencial
const turma1 = new TurmaPresencial('TURMA1', 7, 80);

console.log(`Aluno: ${aluno1.nome}`);
console.log(`Aprovado na turma? ${turma1.aprovado() ? 'Sim' : 'Não'}`);
 