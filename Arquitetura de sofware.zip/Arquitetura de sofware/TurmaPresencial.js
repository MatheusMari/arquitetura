const Turma = require('./Turma ');

class TurmaPresencial extends Turma {
    constructor(codigo, nota, frequencia) {
        super(codigo, nota);
        this.frequencia = frequencia;
    }

    aprovado() {
        // Considera aprovação se nota >= 6 e frequência >= 75%
        return super.aprovado() && this.frequencia >= 75;
    }
}

module.exports = TurmaPresencial;
