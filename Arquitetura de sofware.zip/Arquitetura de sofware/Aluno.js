class Aluno {
    constructor(nome, login, RA) {
        this.nome = nome;
        this.login = login;
        this.RA = RA;
    }
}

module.exports = Aluno;
